({
    mustDeps : { block: 'common-styles' }
    
})
