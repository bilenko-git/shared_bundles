({
    shouldDeps: [{
    	elem: 'head-info',
    	mods: { closed: true }
    }, {
        elem: 'button',
        mods: { toggle: 'closed' }
    }, {
        elem: 'button',
        mods: { toggle: true }
    }, {
    	elem: 'content',
    	mods: { closed: true }
    }]
})
