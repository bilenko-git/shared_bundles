({
    shouldDeps: [
        { block: 'button', mods: { search: true } }
    ]
})
